package com.luma.project.genericutility;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebdriverUtility {
	public void implicitWaitInSeconds(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(25));
	}

	public void implicitWaitInMillis(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(25));
	}

	public boolean verifyCompleteTitle(WebDriver driver, String expectedTitle) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		boolean validation = wait.until(ExpectedConditions.titleIs(expectedTitle));
		return validation;
	}

	public boolean verifyPartialUrl(WebDriver driver, String expectedUrl) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		boolean validation = wait.until(ExpectedConditions.urlContains(expectedUrl));
		return validation;
	}

	public WebDriver controlTransferToWindow(WebDriver driver, String windowId) {
		WebDriver updateDriver = driver.switchTo().window(windowId);
		return updateDriver;
	}

	public WebElement elementToBeClickable(WebDriver driver, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		WebElement ele = wait.until(ExpectedConditions.elementToBeClickable(element));
		return ele;
	}

	public boolean partialTitle(WebDriver driver, String partialTitle) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		boolean validation = wait.until(ExpectedConditions.titleContains(partialTitle));
		return validation;
	}
}