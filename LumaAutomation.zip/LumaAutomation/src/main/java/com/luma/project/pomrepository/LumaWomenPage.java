package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaWomenPage {
	WebDriver driver;

	public LumaWomenPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[text()='Tops']")
	private WebElement topsOption;
	@FindBy(xpath = "//a[contains(.,'Sign Out')]")
	private WebElement customerWelcomeOption;
//	@FindBy(xpath = "//a[@class='action showcart']")
//	private WebElement cartOption;
//
//	@FindBy(xpath = "//a[@title='Remove item']")
//	private WebElement removeoption;
//	@FindBy(xpath = "//button[.='OK']")
//	private WebElement okButton;
	@FindBy(xpath = "//div[@class='panel wrapper']//li//ul[@class='header links']//a[contains(.,'Sign Out')]")
	private WebElement signOutOption;

	public WebElement getCustomerWelcomeOption() {
		return customerWelcomeOption;
	}

	public WebElement getSignOutOption() {
		return signOutOption;
	}

	public WebElement getTopsOption() {
		return topsOption;
	}
}