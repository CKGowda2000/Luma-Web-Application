package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaSignInPage {
	WebDriver driver;

	public LumaSignInPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='panel header']//a[contains(.,'Sign In')]")
	private WebElement signInOption;
	@FindBy(xpath = "//div[@class='panel wrapper']//li[@class='customer-welcome']")
	private WebElement customerWelcomeOption;
	@FindBy(xpath = "//div[@class='panel wrapper']//li//ul[@class='header links']//a[contains(.,'Sign Out')]")
	private WebElement signOutOption;

	public WebElement getCustomerWelcomeOption() {
		return customerWelcomeOption;
	}

	public WebElement getSignOutOption() {
		return signOutOption;
	}

	public WebElement getSignInOption() {
		return signInOption;
	}
}