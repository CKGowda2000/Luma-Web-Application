package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaHomePageForMen {
	WebDriver driver;

	public LumaHomePageForMen(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[.='Men']")
	private WebElement menOption;
	@FindBy(xpath = "//div[@class='panel wrapper']//li[@class='customer-welcome']")
	private WebElement customerWelcomeOption;
	@FindBy(xpath = "//div[@class='panel wrapper']//li//ul[@class='header links']//a[contains(.,'Sign Out')]")
	private WebElement signOutOption;
	@FindBy(xpath = "//a[@class='action showcart']")
	private WebElement cartOption1;

	@FindBy(xpath = "//a[@title='Remove item']")
	private WebElement removeoption;
	@FindBy(xpath = "//button[.='OK']")
	private WebElement okButton;
	@FindBy(xpath = "//div[@class='panel header']/descendant::a[text()='Create an Account']")
	private WebElement createAnAccountOption;

	public WebElement getCreateAnAccountOption() {
		return createAnAccountOption;
	}

	public WebElement getCartOption1() {
		return cartOption1;
	}

	public WebElement getRemoveoption() {
		return removeoption;
	}

	public WebElement getOkButton() {
		return okButton;
	}

	public WebElement getMenOption() {
		return menOption;
	}

	public WebElement getCustomerWelcomeOption() {
		return customerWelcomeOption;
	}

	public WebElement getSignOutOption() {
		return signOutOption;
	}

}