package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaCheckoutPage {
	WebDriver driver;

	public LumaCheckoutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "company")
	private WebElement companyTextField;
	@FindBy(name = "street[0]")
	private WebElement street1TextField;
	@FindBy(name = "street[1]")
	private WebElement street2TextField;
	@FindBy(name = "street[2]")
	private WebElement street3TextField;
	@FindBy(name = "city")
	private WebElement cityTextField;
	@FindBy(xpath = "//span[text()='Country']/../..//select[@name='country_id']//option[text()='India']")
	private WebElement countryDropdown;
	@FindBy(xpath = "//span[text()='State/Province']/../..//select[@name='region_id']//option[text()='Karnataka']")
	private WebElement stateDropdown;
	@FindBy(name = "postcode")
	private WebElement zipCodeTextField;
	@FindBy(name = "telephone")
	private WebElement phoneNoTextField;
	@FindBy(css = "input[value='flatrate_flatrate']")
	private WebElement flatRateRadioButton;
	@FindBy(css = "input[value='tablerate_bestway']")
	private WebElement bestWayRadioButton;
	@FindBy(xpath = "//button[@class='button action continue primary']")
	private WebElement nextButton;
	@FindBy(xpath = "//a[@aria-label='store logo']")
	private WebElement lumaLogoButton;

	public WebElement getLumaLogoButton() {
		return lumaLogoButton;
	}

	public WebElement getNextButton() {
		return nextButton;
	}

	public WebElement getCountryDropdown() {
		return countryDropdown;
	}

	public WebElement getStateDropdown() {
		return stateDropdown;
	}

	public WebElement getZipCodeTextField() {
		return zipCodeTextField;
	}

	public WebElement getPhoneNoTextField() {
		return phoneNoTextField;
	}

	public WebElement getFlatRateRadioButton() {
		return flatRateRadioButton;
	}

	public WebElement getBestWayRadioButton() {
		return bestWayRadioButton;
	}

	public WebElement getCompanyTextField() {
		return companyTextField;
	}

	public WebElement getStreet1TextField() {
		return street1TextField;
	}

	public WebElement getStreet2TextField() {
		return street2TextField;
	}

	public WebElement getStreet3TextField() {
		return street3TextField;
	}

	public WebElement getCityTextField() {
		return cityTextField;
	}

}